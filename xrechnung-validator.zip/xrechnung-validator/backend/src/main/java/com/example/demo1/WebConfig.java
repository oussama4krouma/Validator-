package com.example.demo1;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * CORS setup.
 *
 * <p>The allowed origin is NOT hardcoded: it comes from the property
 * {@code app.cors.allowed-origins} and can be overridden at runtime with the
 * environment variable {@code APP_CORS_ALLOWED_ORIGINS} — so the same build
 * runs locally and in the DMZ without a code change.</p>
 *
 * <p>Note: when frontend and backend are served from the same host (frontend on
 * {@code /}, backend on {@code /api}), requests are same-origin and CORS does
 * not apply at all. This config then simply has no effect.</p>
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Value("${app.cors.allowed-origins}")
    private String[] allowedOrigins;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins(allowedOrigins)
                .allowedMethods("GET", "POST", "OPTIONS");
    }
}
