# Testing the validator

## Quick start (bundled files)

- `not-an-invoice.xml` — well-formed XML that is **not** an invoice.
  Expected result in the app: **INVALID** (red). Use this to confirm the error path.

For a **VALID** result you need a real, conformant invoice. Hand-writing one that passes
all EN 16931 + XRechnung rules is error-prone, so use the official test instances below.

## Official test data (recommended)

**KoSIT XRechnung Test Suite** — the authoritative set of test invoices:
https://github.com/itplr-kosit/xrechnung-testsuite

```bash
git clone https://github.com/itplr-kosit/xrechnung-testsuite.git
```

Where to look, and what to expect:

| Folder                                   | Syntax        | Expected in your app |
|------------------------------------------|---------------|----------------------|
| `src/test/business-cases/standard/`      | UBL & CII     | VALID                |
| `src/test/business-cases/extension/`     | UBL & CII     | VALID (Extension)    |
| `src/test/technical-cases/`              | mixed         | MIXED — do not assume valid |

File naming: `*_ubl.xml` = UBL syntax, `*_cii.xml` / uncefact = UN/CEFACT CII syntax.
Mustang validates both, so test one of each.

A single well-known valid UBL invoice to start with:
`src/test/business-cases/standard/01.01a-INVOICE_ubl.xml`

## Version alignment (important)

The test suite `master` branch tracks the **current** XRechnung version. Your backend uses
**Mustang 2.24.0**, which embeds its own (possibly older) Schematron rules. If they differ, a
file that is valid under the newest spec may come back with extra notices — or a rule failure —
in your app. That is a version mismatch, not a bug in your code.

If a `business-cases/standard` file is unexpectedly INVALID, check out a test-suite release tag
closer to the XRechnung version your Mustang 2.24.0 targets, then re-test.

## Alternative source

The Mustangproject repository also ships sample ZUGFeRD / Factur-X / XRechnung files in its
test resources: https://github.com/ZUGFeRD/mustangproject
