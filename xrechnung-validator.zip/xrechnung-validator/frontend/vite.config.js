import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5173,
    // In development the frontend runs on 5173 and the backend on 8080.
    // Forward /api to the backend so the relative API_URL works locally,
    // exactly as nginx will do in the DMZ.
    proxy: {
      '/api': 'http://localhost:8080',
    },
  },
});
